import {html} from '../../node_modules/lit-html/lit-html.js';
import {getPets} from '../api/data.js';
import {petTemplate} from './common/pet.js';

const dashboardTemplate = (data) => html`
<section id="dashboard-page" class="dashboard">
    <h1>Dashboard</h1>
${data.length !== 0 ? data.map(petTemplate) : html`<p class="no-pets">No pets in database!</p>`}
</section>
`

export async function dashboardPage(ctx) {
    const data = await getPets();

    ctx.render(dashboardTemplate(data));
}