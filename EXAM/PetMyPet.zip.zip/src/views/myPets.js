import { html } from '../../node_modules/lit-html/lit-html.js';
import { getMyPets } from '../api/data.js';
import { petTemplate} from './common/pet.js';

const myPetsTemplate = (pets) => html`
<section id="my-pets-page" class="my-pets">
    <h1>My Pets</h1>
    ${data.length !== 0 ? data.map(petTemplate) : html`<p class="no-pets">No pets in database!</p>` }
</section>
`
export async function myPetsPage(ctx) {
    const id = sessionStorage.getItem('userId');

    const pets = await getMyPets(id);

    ctx.render(myPetsTemplate(pets));
};