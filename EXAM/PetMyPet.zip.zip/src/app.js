import {page} from '../node_modules/page/page.mjs';
import {render} from '../node_modules/lit-html/lit-html.js';
import { dashboardPage } from './views/dashboard.js';
import {myPetsPage} from './views/myPets.js'
import {detailsPage} from './views/details.js'
import {createPage} from './views/create.js';
import {editPage} from './views/edit.js';
import { loginPage } from './views/login.js';
import { registerPage } from './views/register.js';

const main = document.querySelector('site-content');

page('/', decorateContext, dashboardPage);
page('/myPets', decorateContext, myPetsPage);
page('/details/:id', decorateContext, detailsPage);
page('/create', decorateContext, createPage);
page('/edit/:id', decorateContext, editPage);
page('/register', decorateContext, registerPage);
page('/login', decorateContext, loginPage);

setUserNav();
page.start();

document.getElementById('logoutBtn').addEventListener('click', async () => {
    await logout();
    setUserNav();
    page.redirect('/');
});

function decorateContext(ctx, next) {
    ctx.render = (content) => render(content, main);
    ctx.setUserNav = setUserNav;
    next();
}

function setUserNav() {
    const email = sessionStorage.getItem('email');
    if(email != null) {
        document.querySelector('div').textContent = `Welcome, ${email}`;
        document.querySelector('#user').style.display = 'inline-block';
        document.querySelector('#guest').style.display = 'none';
    } else {
        document.querySelector('#user').style.display = 'none';
        document.querySelector('#guest').style.display = 'inline-block';
    }
}